import os
from ament_index_python.packages import get_package_share_directory, get_package_prefix
from launch import LaunchDescription
from launch.actions import RegisterEventHandler, DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
import launch_ros.parameter_descriptions
from launch_ros.actions import Node
from launch.event_handlers import OnProcessExit
import xacro



def generate_launch_description():
    pkg_dir = get_package_share_directory('amr_mani_description')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    xacro_file = os.path.join(pkg_dir, 'urdf', 'amr_mani.xacro')
    robot_description_config = xacro.parse(open(xacro_file)) 
    robot_desc = robot_description_config.toxml()
    # robot_urdf = os.path.join(pkg_dir, 'urdf', 'amr_mani.urdf')
    bridge_params_fp = os.path.join(pkg_dir, 'config', 'bridge_params.yaml')

    sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='True',
        description='whether to use simulation time or not'
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[
            {
                'use_sim_time': LaunchConfiguration('use_sim_time'),
                'robot_description': robot_desc
            }
        ]
    )

    gz_launcher = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': PathJoinSubstitution([
            pkg_dir,
            'world',
            f'empty.sdf -r' 
        ])}.items(),
    )

    bot_spawner_cmd = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-string', robot_desc,
            '-name', 'amr_mani',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '1.0'
        ],
        output='screen',
    )

    gz_ros2_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=[
            '--ros-args',
            '-p',
            f'config_file:={bridge_params_fp}',
        ],
        output='screen',
    )

    load_joint_state_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active',
             'joint_state_broadcaster'],
        output='screen'
    )

    load_joint_trajectory_controller = ExecuteProcess(
        cmd=['ros2', 'control', 'load_controller', '--set-state', 'active',
             'joint_trajectory_controller'],
        output='screen'
    )

    joint_state_event_handler = RegisterEventHandler(
        OnProcessExit(
            target_action=bot_spawner_cmd,
            on_exit=[load_joint_state_controller]
        )
    )

    controller_event_handler = RegisterEventHandler(
        OnProcessExit(
        target_action=load_joint_state_controller,
        on_exit=[load_joint_trajectory_controller]
    ))


    ld = LaunchDescription()
    ld.add_action(sim_time_arg)
    ld.add_action(gz_ros2_bridge)
    ld.add_action(robot_state_publisher)
    ld.add_action(gz_launcher)
    ld.add_action(bot_spawner_cmd)
    ld.add_action(joint_state_event_handler)
    ld.add_action(controller_event_handler)

    return ld