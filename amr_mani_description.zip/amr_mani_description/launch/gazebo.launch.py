from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, LaunchConfiguration
from launch.conditions import IfCondition
import os
import xacro
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    share_dir = get_package_share_directory('amr_mani_description')

    xacro_file = os.path.join(share_dir, 'urdf', 'amr_mani.xacro')
    robot_description_config = xacro.process_file(xacro_file) 
    robot_urdf = robot_description_config.toxml()

    world_name = 'empty'
    world_file_path = os.path.join(share_dir, 'world', f"{world_name}.world")

    scan_filter_config = os.path.join(share_dir, 'config/', 'laser_filter.yaml')

    world = LaunchConfiguration('world')
    world_cmd = DeclareLaunchArgument(
        name='world',
        default_value='empty',
        description='Full path to the world model file to load'
    )

    pause_sim_cmd = DeclareLaunchArgument(
        'pause_sim',
        default_value='true',
        description='whether to pause or play the simulation when gazebo env is launced'
    )

    use_sim_time_arg = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='whether to use simulation time or real-sys time'
    )

    obs_arg = DeclareLaunchArgument(
        'obs',
        default_value='false',
        description='whether to add random obstacles or delete the existing obstacles'
    )

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[
            {'robot_description': robot_urdf, 'use_sim_time': LaunchConfiguration('use_sim_time')}
        ]
    )

    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzserver.launch.py'
            ])
        ]),
        launch_arguments={
            'pause': LaunchConfiguration('pause_sim'),
            'world': f'{world_file_path}'
        }.items()
    )

    gazebo_client = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gzclient.launch.py'
            ])
        ])
    )

    urdf_spawn_node = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', 'amr_ust',
            '-topic', 'robot_description',
            '-z', '0.2'
        ],
        output='screen'
    )

    joint_broad_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster', '--controller-manager', '/controller_manager']
    )

    joint_trajectory_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_trajectory_controller', '--controller-manager', '/controller_manager']
    )

    obstacle_spawner_node = Node(
        package='obs_spawner',
        executable='obs_spawner.py',
        output='screen',
        arguments=['spawn'],
        condition=IfCondition(LaunchConfiguration('obs'))
    )

    laser_filter_node = Node(
        package='laser_filters',
        executable='scan_to_scan_filter_chain',
        parameters=[scan_filter_config],
        output='screen'
    )

    return LaunchDescription([
        world_cmd,
        pause_sim_cmd,
        use_sim_time_arg,
        obs_arg,
        robot_state_publisher_node,
        gazebo_server,
        gazebo_client,
        urdf_spawn_node,
        joint_broad_spawner,
        joint_trajectory_spawner,
        obstacle_spawner_node
    ])
 